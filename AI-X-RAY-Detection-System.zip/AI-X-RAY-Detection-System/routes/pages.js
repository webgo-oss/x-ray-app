const express = require('express');
const mongoose = require('mongoose');
const axios = require('axios');
const Scan = require('../models/Scan');
const { requireAuth } = require('../middleware/auth');
const { generateCsrfToken } = require('../middleware/csrf');

const router = express.Router();

router.get('/health', (req, res) => {
  const dbConnected = mongoose.connection.readyState === 1;
  res.status(dbConnected ? 200 : 503).json({
    status: dbConnected ? 'ok' : 'degraded',
    db: dbConnected ? 'connected' : 'disconnected',
    uptime: process.uptime()
  });
});

router.get('/main', (req, res) => {
  res.render('index', { user: req.session.user || null, csrfToken: generateCsrfToken(req, res) });
});

router.get('/infomation', (req, res) => {
  res.render('info', { user: req.session.user || null });
});

router.get('/nearby-doctors', requireAuth, (req, res) => {
  res.render('nearby', { user: req.session.user });
});

router.get('/about', (req, res) => {
  res.render('about_me', { user: req.session.user || null });
});

const PAGE_SIZE = 10;

router.get('/dashboard', requireAuth, async (req, res) => {
  try {
    const page = Math.max(1, parseInt(req.query.page, 10) || 1);

    const [history, totalScans] = await Promise.all([
      Scan.find({ user_id: req.session.user.id })
        .sort({ created_at: -1 })
        .skip((page - 1) * PAGE_SIZE)
        .limit(PAGE_SIZE)
        .lean(), // read-only render — skip Mongoose document overhead
      Scan.countDocuments({ user_id: req.session.user.id })
    ]);

    const totalPages = Math.max(1, Math.ceil(totalScans / PAGE_SIZE));

    res.render('userdashboard', {
      user: req.session.user,
      history,
      count: totalScans,
      currentPage: page,
      totalPages,
      csrfToken: generateCsrfToken(req, res)
    });
  } catch (err) {
    console.error('Dashboard error:', err.message);
    res.status(500).render('error', { error: 'Could not load dashboard' });
  }
});

// Overpass must be called server-to-server: the public mirrors increasingly
// block/rate-limit direct browser CORS requests (406/429), and even when they
// don't, racing several from the browser at once looks like abuse to them.
// A server has no CORS restriction at all, so this route does the querying
// and the frontend just calls this instead of Overpass directly.
const OVERPASS_ENDPOINTS = [
  'https://overpass-api.de/api/interpreter',
  'https://overpass.kumi.systems/api/interpreter',
  'https://overpass.openstreetmap.ru/api/interpreter'
];
const OVERPASS_TIMEOUT_MS = 15000;

function haversineKm(lat1, lon1, lat2, lon2) {
  const R = 6371;
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLon = (lon2 - lon1) * Math.PI / 180;
  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
    Math.sin(dLon / 2) ** 2;
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

function buildOverpassQuery(lat, lon, radiusMeters) {
  // bbox instead of (around:) — Overpass has to compute an exact distance
  // for every candidate with (around:), which is measurably slower than an
  // indexed bbox lookup. We trim back to the real circle below with haversine.
  const latDelta = radiusMeters / 111320;
  const lonDelta = radiusMeters / (111320 * Math.cos(lat * Math.PI / 180));
  const south = lat - latDelta, north = lat + latDelta;
  const west = lon - lonDelta, east = lon + lonDelta;
  return `[out:json][timeout:20];
(
  node["amenity"~"^(hospital|clinic|doctors|pharmacy)$"](${south},${west},${north},${east});
  way["amenity"~"^(hospital|clinic|doctors|pharmacy)$"](${south},${west},${north},${east});
);
out center tags;`;
}

function parseOverpassPlaces(elements, lat, lon) {
  return (elements || [])
    .map((el) => {
      const elLat = el.lat ?? (el.center && el.center.lat);
      const elLon = el.lon ?? (el.center && el.center.lon);
      if (elLat == null || elLon == null) return null;

      const tags = el.tags || {};
      const name = tags.name || (tags.amenity ? `Unnamed ${tags.amenity}` : 'Unnamed place');
      const address = [tags['addr:housenumber'], tags['addr:street'], tags['addr:city']]
        .filter(Boolean).join(', ');

      return {
        id: `${el.type}/${el.id}`,
        name,
        type: tags.amenity || 'other',
        phone: tags.phone || tags['contact:phone'] || null,
        address: address || null,
        lat: elLat,
        lon: elLon,
        distance: haversineKm(lat, lon, elLat, elLon)
      };
    })
    .filter(Boolean)
    .sort((a, b) => a.distance - b.distance);
}

router.get('/api/nearby', requireAuth, async (req, res) => {
  const lat = parseFloat(req.query.lat);
  const lon = parseFloat(req.query.lon);
  const radius = Math.min(Math.max(parseInt(req.query.radius, 10) || 5000, 500), 20000);

  if (!Number.isFinite(lat) || !Number.isFinite(lon) || lat < -90 || lat > 90 || lon < -180 || lon > 180) {
    return res.status(400).json({ error: 'Invalid lat/lon' });
  }

  const query = buildOverpassQuery(lat, lon, radius);

  const attempts = OVERPASS_ENDPOINTS.map((endpoint) =>
    axios.post(endpoint, 'data=' + encodeURIComponent(query), {
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      timeout: OVERPASS_TIMEOUT_MS
    }).then((r) => ({ data: r.data, endpoint }))
  );

  try {
    const winner = await Promise.any(attempts);
    const radiusKm = radius / 1000;
    const places = parseOverpassPlaces(winner.data.elements, lat, lon)
      .filter((p) => p.distance <= radiusKm);
    res.json({ places });
  } catch (aggregateErr) {
    console.error('Overpass fetch failed on all mirrors:',
      (aggregateErr.errors || []).map((e) => e.message).join('; '));
    res.status(502).json({ error: 'Could not reach the places service. Please try again shortly.' });
  }
});

module.exports = router;
